def print_kumoh():
    print("Kumoh National Institute od Technology.")
    
def print_hello():
    print("Hello World!")
    
def add(x,y):
    return x + y

print_kumoh()
print_hello()
print("2 + 3 >> {}".format(add(2,3)))